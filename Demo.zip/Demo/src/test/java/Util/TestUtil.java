package Util;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.*;
import java.util.concurrent.TimeUnit;
/**
 * Created by Merlin on 31/07/2019.
 * All Generic support libraries are defined
 */
public  class TestUtil extends TestBase{

        static int PAGE_LOAD_TIMEOUT = 20;
        static int IMPLICIT_WAIT = 30;
}
