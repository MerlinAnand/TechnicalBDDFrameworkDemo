package stepDefinitions;

import Pages.HomePage;
import Util.TestBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

/**
 * Created by Merlin on 31/07/2019.
 */

public class HomePageSteps {

    WebDriver driver;
    HomePage homePage;

    @Given("user navigates the url")
    public void user_navigates_the_url() {
       TestBase.initialization();
    }

   @When("the home page title is displayed")
    public void the_home_page_title_is_displayed() {
       homePage = new HomePage();
       String pageTitle= homePage.verifyHomePageTitle();
       Assert.assertEquals(true, pageTitle.toLowerCase().contains("qantas"));
    }

    @Then("user enters the from {string} and {string}")
    public void user_enters_the_from_and(String from, String to) throws InterruptedException {
        homePage.search(from,to);
    }

    @Then("^Application should be closed$")
    public void application_should_close(){
        TestBase.closeApp();
    }
}
