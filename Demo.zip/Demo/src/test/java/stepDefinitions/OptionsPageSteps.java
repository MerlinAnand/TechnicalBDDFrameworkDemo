package stepDefinitions;
import Pages.OptionsPage;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
/**
 * Created by Merlin on 31/07/2019.
 */
public class OptionsPageSteps {

    WebDriver driver;
    OptionsPage optionsPage = new OptionsPage();

    @Then("user add {} in checked baggage and seats")
    public void user_add_bag_in_checked_baggage_and_seats(int bagCount) throws InterruptedException {
        optionsPage.addBag(bagCount);
    }

}
