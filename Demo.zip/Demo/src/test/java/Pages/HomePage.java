package Pages;

import Util.GetDate;
import Util.TestBase;
import Util.TestUtil;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Merlin on 31/07/2019.
 */
public class HomePage extends TestBase {

    //Creating the JavascriptExecutor interface object by Type casting
    JavascriptExecutor js = (JavascriptExecutor) driver;

    // Page Factory - OR
    @FindBy(xpath = "//input[@id='typeahead-input-from']")
    WebElement txtfrom;

    @FindBy(xpath = "//input[@id='typeahead-input-to']")
    WebElement txtto;

    @FindBy(xpath = "//input[@id='datepicker-input-departureDate']")
    WebElement txtdepart;

    @FindBy(xpath = "//td[@aria-label='Sunday, the twenty fifth of August 2019']")
    WebElement txtdate;

    @FindBy(xpath = "//div[@class='only-show-for-tablet-desktop']/div[2]/div/fieldset/div/div/input[@aria-label='One way']")
    WebElement rdtrip;

    @FindBy(xpath = "//div[@class='qfa1-submit-button__container-right widget-form__group-container size-big']")
    WebElement btnSearch;

    @FindBy(xpath = "//*[@id=\"collapsibleCard0\"]/div[2]/cart-collapsible-card-footer/cart-flights-subtotal/div/div[1]/div[2]/div/cart-subtotal-row/span[1]")
    WebElement txtSubtotal;


    public HomePage() {
        PageFactory.initElements(driver, this);
    }

    public String verifyHomePageTitle(){
        return driver.getTitle();
    }

 /*

    Capture the year and compare if that's your expected year. If not first set the proper year with the navigation.
    Capture the Month and compare if that's your expected month. If not first set the proper month with the navigation.
    Select the date from date-picker. */

    public SearchPage search(String source, String des) throws InterruptedException, ParseException {
        String result = driver.toString();
        if (!result.isEmpty()) {
            verify_Element_displayed(txtfrom);
            typeText(txtfrom,source);

            verify_Element_displayed(txtto);
            Click(txtto);

            typeText(txtto,des);
            txtto.sendKeys(Keys.ENTER);
            //Perform Click on Oneway  button using JavascriptExecutor
            js.executeScript("arguments[0].click();", rdtrip);

            verify_Element_displayed(txtdepart);
            txtdepart.click();

            verify_Element_displayed(txtdate);
            txtdate.click();

            verify_Element_displayed(btnSearch);
            btnSearch.click();
            Assert.assertEquals("$0", txtSubtotal.getText());

        } else {
            Assert.assertFalse("Browser not launched", result.isEmpty());
        }
        return new SearchPage();
    }

    /*
    This method returns the WebElement based on the date set in the calendar
     */
    public WebElement setDate() throws ParseException {
        // get the days 15 in advance for the booking
        String newdate = GetDate.getSdf(15);
        SimpleDateFormat sdf = new SimpleDateFormat(newdate);
        Date parse = sdf.parse(newdate);
        Calendar c = Calendar.getInstance();
        c.setTime(parse);
        int Day=c.get(Calendar.MONTH);
        int Month = c.get(Calendar.DATE);
        int Year = c.get(Calendar.YEAR);
        WebElement dateElement= (WebElement) By.xpath("//td[@aria-label='+ Day + Month + Year']");
        return dateElement;
    }

}


