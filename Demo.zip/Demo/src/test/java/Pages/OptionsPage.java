package Pages;
import Util.TestBase;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;
/**
 * Created by Merlin on 31/07/2019.
 */
public class OptionsPage extends TestBase {

    @FindBy(xpath = "//*[@id=\"PH_passenger_baggage_promoADT\"]/div/div/div[3]/button/span[1]")
    WebElement lnkAddBag;

    @FindBy(xpath = "//*[@id=\"bags-btn-continue\"]")
    WebElement btnBagContinue;

    @FindBy(xpath = "//*[@id=\"bagsTermsAndConditionsModal\"]/div/div/div[2]/navigation-ribbon/navigation-ribbon-view-tac/div/nav/div[2]/button")
    WebElement btnBagAccept;

    @FindBy(xpath = "//*[@id=\"PH_passenger_baggage_promoADT\"]/div/div/div[3]/button/span[2]")
    WebElement lnkEditBag;

    @FindBy(xpath = "//*[@id=\"passengerADT1\"]/div/div/div[2]/form/add-bags-bound-input/div/button[2]/i")
    WebElement lnkInr;

    public OptionsPage() {
        PageFactory.initElements(driver, this);
    }

    public String VerifyOptionsPageTitle() {
        return driver.getTitle();
    }

    public void addBag(Integer bagCount) throws InterruptedException {

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();"
                , lnkAddBag);
        verify_Element_displayed(lnkAddBag);
        lnkAddBag.click();
        for(int ctr=1; ctr<=bagCount; ctr++) {
            if (ctr>1){
                verify_Element_displayed(lnkInr);
                lnkInr.click();
            }}
        verify_Element_displayed(btnBagContinue);
        btnBagContinue.click();
        verify_Element_displayed(btnBagAccept);
        btnBagAccept.click();
    }
}
